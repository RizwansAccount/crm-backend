import mongoose from "mongoose";

const schemaStructure = {
    name: { type: String, required: true },
    width: { type: Number, required: true },
    height: { type: Number, required: true },
    image: { type: String, required: true },
    image_link: { type: String, required: true },
    product_id: { type: Number, required: true }
};

const schema = new mongoose.Schema(schemaStructure, { timestamps: true });
export default mongoose.model("Product", schema);