import mongoose from "mongoose";

const canvasSchema = new mongoose.Schema({
  json: { type: String, required: true },  // Store canvas data as a JSON string
  width: { type: Number, required: true },
  height: { type: Number, required: true }
});

export default mongoose.model("Canvas", canvasSchema);