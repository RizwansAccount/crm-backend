import mongoose from "mongoose";

// Canvas schema
const containerScheme = new mongoose.Schema({
    containerId: { type: String, required: true, unique: true }, // Associate canvas with container ID
    json: { type: String, required: true },                      // Store canvas data as a JSON string
    width: { type: Number, required: false },                   // Optional width
    height: { type: Number, required: false }                   // Optional height
});

export default mongoose.model("Container", containerScheme);