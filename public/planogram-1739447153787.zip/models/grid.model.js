import mongoose from "mongoose";

const schemaStructure = {
    project_id: { type: String, required : true },
    racks: [{
        rack_number: { type: Number, required: true },
        width: { type: Number, required: true },
        height: { type: Number, required: true },
        x: { type: Number, required: true },
        y: { type: Number, required: true }
    }],
    products: [{
        product_id : { type : Number, required : true },
        rack_number: { type: Number, required: true },
        width: { type: Number, required: true },
        height: { type: Number, required: true },
        x: { type: Number, required: true },
        y: { type: Number, required: true },
        image_link : { type: String, required : true }
    }],
    dimensions: {
        grid_width: { type: Number, required: true },
        grid_height: { type: Number, required: true },
    }
};

const schema = new mongoose.Schema(schemaStructure, { timestamps: true });

export default mongoose.model("Grid", schema);