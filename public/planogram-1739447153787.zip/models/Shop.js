import mongoose from "mongoose";

// Shop schema
const shopSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  name: { type: String, required: true },
  width: { type: Number, required: true },
  height: { type: Number, required: true },
  canvas: { type: mongoose.Schema.Types.ObjectId, ref: 'Canvas' }
});

export default mongoose.model("Shop", shopSchema);
