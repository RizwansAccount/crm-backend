const urlParams = new URLSearchParams(window.location.search);
const projectId = urlParams.get('id');


// ****************** Variables ****************** //
let gridWidth = 0;
let gridHeight = 0;
let racks = [];
let products = [];
let currentDraggedProduct = null;
let lastValidPosition = null;
let currentRackWidth = 200;
let currentRackHeight = 200;
let selectedProduct = null;
let validPositions = [];
let rackCount = 0;
let isGridCreated = false;

// ***************** DOM ELEMENTS ****************** //
const gridContainer = document.getElementById("gridContainer");
const createGridModal = document.getElementById("createGridModal");
const createRackModal = document.getElementById("createRackModal");
const createProductModal = document.getElementById('createProductModal');
const createGridBtn = document.getElementById("createGridBtn");
const addRackBtn = document.getElementById("addRackBtn");
const addProductBtn = document.getElementById("addProductBtn");
const removeProductBtn = document.getElementById('removeProductBtn');
const createProductModalBtn = document.getElementById('createProductModalBtn');
const closeProductModalBtn = document.getElementById('closeProductModalBtn');
const closeGridModalBtn = document.getElementById('closeGridModalBtn');
const closeRackModalBtn = document.getElementById('closeRackModalBtn')
const productName = document.getElementById('name');
const productHeight = document.getElementById('height');
const productWidth = document.getElementById('width');
const inputProductId = document.getElementById('inputProductId');


// ********************** Functions ********************* //
function exportGridAsJson() {
    const gridData = {
        project_id: projectId,
        racks: racks?.map(rack => ({
            rack_number: parseInt(rack.dataset.rackNumber),
            width: parseInt(rack.style.width),
            height: parseInt(rack.style.height),
            x: parseInt(rack.style.left),
            y: parseInt(rack.style.top)
        })),
        products: products?.map(product => ({
            product_id : parseInt(product.dataset.product_id),
            rack_number: parseInt(product.dataset.rackNumber),
            width: parseInt(product.style.width),
            height: parseInt(product.style.height),
            x: parseInt(product.style.left),
            y: parseInt(product.style.top),
            image_link: product.dataset.image_link
        })),
        dimensions: {
            grid_width: gridWidth,
            grid_height: gridHeight,
            rack_width: currentRackWidth,
            rack_height: currentRackHeight
        }
    };

    const dataStr = JSON.stringify(gridData, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = window.URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `grid-layout-${projectId}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.URL.revokeObjectURL(url);
};

async function importGridFromJson(file) {
    try {
        const reader = new FileReader();
        
        reader.onload = async (e) => {
            try {
                let gridData = JSON.parse(e.target.result);
                
                // Override the project_id with current project_id
                gridData.project_id = projectId;
                
                // Send to API
                const response = await fetch('/api/grid/create', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(gridData)
                });

                const result = await response.json();
                
                if (result.success) {
                    // Clear existing grid
                    initializeGrid();
                    
                    // Load the new grid state
                    await loadGridState();
                    
                } else {
                    alert('Failed to import grid: ' + (result.message || 'Unknown error'));
                }
            } catch (error) {
                console.error('Error parsing JSON:', error);
                alert('Invalid grid layout file');
            }
        };

        reader.readAsText(file);
    } catch (error) {
        console.error('Error importing grid:', error);
        alert('Failed to import grid layout');
    }
};

function handleCreateGrid() {
    const width = parseInt(document.getElementById('gridWidth').value);
    const height = parseInt(document.getElementById('gridHeight').value);

    if (!width || !height || width < 200 || height < 200) {
        alert('Please enter valid dimensions (minimum 200px)');
        return;
    }

    gridWidth = width;
    gridHeight = height;
    isGridCreated = true;

    initializeGrid();
    createGridModal.style.display = 'none';
    addRackBtn.style.display = 'block';
    createGridBtn.style.display = 'none';

    saveGridState();
};

function handleAddRack() {
    if (!isGridCreated) {
        alert('Please create a grid first');
        return;
    }

    const width = parseInt(document.getElementById('rackWidth').value);
    const height = parseInt(document.getElementById('rackHeight').value);

    if (!width || !height || width < 100 || height < 100) {
        alert('Please enter valid rack dimensions (minimum 100px)');
        return;
    }

    if (width > gridWidth || height > gridHeight) {
        alert(`Rack dimensions (${width}x${height}) cannot exceed grid dimensions (${gridWidth}x${gridHeight})`);
        return;
    }

    // Find the next available position for the rack
    const position = findNextRackPosition(width, height);
    if (!position) {
        alert('No space available in grid for new rack');
        createRackModal.style.display = 'none';
        return;
    }

    const rack = createRack(position.x, position.y, width, height);
    rack.dataset.rackNumber = ++rackCount;
    gridContainer.appendChild(rack);
    racks.push(rack);
    createRackModal.style.display = 'none';
    saveGridState();
};

function isSpaceAvailable(x, y, width, height) {
    // First check if the proposed rack would fit within the grid bounds
    if (x < 0 || y < 0 || x + width > gridWidth || y + height > gridHeight) {
        return false;
    }

    // Check if the proposed rack position overlaps with any existing racks
    return !racks.some(rack => {
        const rackX = parseInt(rack.style.left);
        const rackY = parseInt(rack.style.top);
        const rackWidth = parseInt(rack.style.width);
        const rackHeight = parseInt(rack.style.height);

        // Check for any overlap in both dimensions
        const hasHorizontalOverlap = !(x + width <= rackX || x >= rackX + rackWidth);
        const hasVerticalOverlap = !(y + height <= rackY || y >= rackY + rackHeight);

        return hasHorizontalOverlap && hasVerticalOverlap;
    });
};

function findNextRackPosition(rackWidth, rackHeight) {
    const width = rackWidth || currentRackWidth;
    const height = rackHeight || currentRackHeight;

    // Check if the rack dimensions are valid for the grid
    if (width > gridWidth || height > gridHeight) {
        return null;
    }

    // Try to find the first available position that fits the rack
    // Increment by smaller steps (e.g., 10px) for more precise placement
    for (let y = 0; y <= gridHeight - height; y += 10) {
        for (let x = 0; x <= gridWidth - width; x += 10) {
            if (isSpaceAvailable(x, y, width, height)) {
                return { x, y };
            }
        }
    }
    return null;
};

async function saveGridState() {
    const gridData = {
        project_id: projectId,
        racks: racks?.map(rack => ({
            rack_number: parseInt(rack.dataset.rackNumber),
            width: parseInt(rack.style.width), 
            height: parseInt(rack.style.height),
            x: parseInt(rack.style.left),
            y: parseInt(rack.style.top)
        })),
        products: products?.map(product => ({
            product_id: parseInt(product.dataset.product_id),
            rack_number: parseInt(product.dataset.rackNumber),
            width: parseInt(product.style.width),
            height: parseInt(product.style.height),
            x: parseInt(product.style.left),
            y: parseInt(product.style.top),
            image_link: product?.dataset.image_link,
        })),
        dimensions: {
            grid_width: gridWidth,
            grid_height: gridHeight,
            rack_width: currentRackWidth, 
            rack_height: currentRackHeight
        }
    };

    try {
        const response = await fetch('/api/grid/create', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(gridData)
        });

        const result = await response.json();
        console.log('Grid state saved successfully:', result);
    } catch (error) {
        console.error('Error saving grid state:', error);
        alert('Failed to save grid state');
    }
};

async function loadGridState() {
    console.log("grid state called")
    try {
        const response = await fetch(`/api/grid/${projectId}`);
        const { data } = await response.json();

        if (!data) {
            return;
        }

        // Set dimensions and initialize
        gridWidth = data.dimensions.grid_width;
        gridHeight = data.dimensions.grid_height;
        currentRackWidth = data.dimensions.rack_width;
        currentRackHeight = data.dimensions.rack_height;

        if (gridWidth && gridHeight) {
            isGridCreated = true;
            createGridBtn.style.display = 'none';
            addRackBtn.style.display = 'block';
        }

        initializeGrid();

        // Create racks
        if (data.racks?.length > 0) {
            data.racks.forEach(rackData => {
                const rack = createRack(rackData.x, rackData.y);
                rack.dataset.rackNumber = rackData.rack_number;
                rack.style.width = `${rackData.width}px`;
                rack.style.height = `${rackData.height}px`;
                gridContainer.appendChild(rack);
                racks.push(rack);
                rackCount = Math.max(rackCount, parseInt(rackData.rack_number));
            });
        }

        // Create products with product_id preserved
        if (data.products?.length > 0) {
            data.products.forEach(productData => {
                const product = document.createElement('div');
                product.classList.add('product');
                product.draggable = true;
                product.dataset.product_id = productData.product_id;  // Ensure product_id is set
                product.dataset.rackNumber = productData.rack_number;
                product.dataset.image_link = productData.image_link;
                product.style.width = `${productData.width}px`;
                product.style.height = `${productData.height}px`;
                product.style.left = `${productData.x}px`;
                product.style.top = `${productData.y}px`;

                const productImage = document.createElement("img");
                productImage.src = productData.image_link;
                productImage.style.width = '100%';
                productImage.style.height = '100%';
                productImage.style.objectFit = 'cover';

                product.appendChild(productImage);
                setupProductEventListeners(product);
                gridContainer.appendChild(product);
                products.push(product);
            });
        }
    } catch (error) {
        console.error('Error loading grid state:', error);
    }
};

const getAllProducts = async () => {
    const data = await fetch(`/api/product`);
    const result = await data.json();
    displayProducts(result?.data);
};

const createProduct = async () => {
    const productId = inputProductId.value;
    const name = productName.value;
    const height = productHeight.value;
    const width = productWidth.value;
    const imageFile = document.getElementById('productImageInput')?.files[0];

    if (!imageFile || !productId || !name || !height || !width) {
        alert('Please filled the all required fields');
        return;
    };

    const formData = new FormData();
    formData.append('product_id', productId);
    formData.append('name', name);
    formData.append('height', height);
    formData.append('width', width);
    formData.append('project_id', projectId);
    formData.append('file', imageFile);

    try {
        const response = await fetch('/api/product', {
            method: 'POST',
            body: formData
        });

        console.log("changes", response);

        if (response.status === 200) {
            createProductModal.style.display = "none";
            getAllProducts();
        } else {
            const errorData = await response.json();
            alert(errorData.message || 'Error creating product');
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Failed to create product');
    }
};

const displayProducts = (products) => {
    const container = document.getElementById('products-container');
    container.innerHTML = '';

    if (products?.length === 0) {
        container.innerHTML = "<p style='font-size:14px' >No products found.</p>";
        return;
    }

    products?.forEach(product => {
        const productDiv = document.createElement('div');
        productDiv.draggable = true;
        productDiv.className = 'display-product';
        productDiv.innerHTML = `
            <img src=${product?.image_link} style="width: ${product?.width}px; height: ${product?.height}px;"  />
        `;

        productDiv.addEventListener("dragstart", (e) => {
            currentDraggedProduct = {
                isTemplate: true,
                product_id: parseInt(product?.product_id),
                width: parseInt(product?.width),
                height: parseInt(product?.height),
                _id: product?._id,
                name: product?.name,
                image_link: product?.image_link
            };
            e.dataTransfer.setData("text/plain", "");
            productDiv.classList.add('dragging');
        });

        productDiv.addEventListener("dragend", (e) => {
            if (currentDraggedProduct && currentDraggedProduct.isTemplate) {
                currentDraggedProduct = null;
                clearValidPositions();
            }
            productDiv.classList.remove('dragging');
        });

        container.appendChild(productDiv);
    });
};

function clearValidPositions() {
    document.querySelectorAll('.valid-position').forEach(el => el.remove());
    validPositions = [];
};

function showValidPosition(x, y, width, height) {
    const indicator = document.createElement('div');
    indicator.className = 'valid-position';
    indicator.style.width = `${width}px`;
    indicator.style.height = `${height}px`;
    indicator.style.left = `${x}px`;
    indicator.style.top = `${y}px`;
    gridContainer.appendChild(indicator);
    validPositions.push({ x, y, element: indicator });
};

function findClosestValidPosition(x, y) {
    if (validPositions.length === 0) return null;

    return validPositions.reduce((closest, current) => {
        const currentDist = Math.hypot(current.x - x, current.y - y);
        const closestDist = closest ? Math.hypot(closest.x - x, closest.y - y) : Infinity;
        return currentDist < closestDist ? current : closest;
    }, null);
};

function initializeGrid() {
    while (gridContainer.firstChild) {
        gridContainer.removeChild(gridContainer.firstChild);
    }
    gridContainer.style.width = `${gridWidth}px`;
    gridContainer.style.height = `${gridHeight}px`;
    gridContainer.style.minHeight = `${parseInt(gridHeight)}px`;
    racks = [];
    products = [];
    rackCount = 0;
    lastValidPosition = null;
    selectedProduct = null;
};

function createRack(x, y, width, height) {
    const rack = document.createElement("div");
    rack.classList.add("rack");
    rack.dataset.rackNumber = rackCount;
    rack.style.width = `${width}px`;
    rack.style.height = `${height}px`;
    rack.style.left = `${x}px`;
    rack.style.top = `${y}px`;
    return rack;
};

function getRackByNumber(rackNumber) {
    return racks.find(rack => parseInt(rack.dataset.rackNumber) === rackNumber);
};

function isValidPosition(x, y, width, height, rack, excludeProduct = null) {
    const rackLeft = parseInt(rack.style.left);
    const rackTop = parseInt(rack.style.top);
    const actualRackWidth = parseInt(rack.style.width);
    const actualRackHeight = parseInt(rack.style.height);

    // Check boundaries using actual rack dimensions
    if (x < rackLeft || y < rackTop ||
        x + width > rackLeft + actualRackWidth ||
        y + height > rackTop + actualRackHeight) {
        return false;
    }

    // Check for overlap with other products
    const hasOverlap = products?.filter(p =>
        p.dataset.rackNumber === rack.dataset.rackNumber &&
        p !== excludeProduct
    )?.some(product => {
        const prodRect = {
            left: parseInt(product.style.left),
            right: parseInt(product.style.left) + parseInt(product.style.width),
            top: parseInt(product.style.top),
            bottom: parseInt(product.style.top) + parseInt(product.style.height)
        };

        const newRect = {
            left: x,
            right: x + width,
            top: y,
            bottom: y + height
        };

        return checkOverlap(newRect, prodRect);
    });

    if (hasOverlap) return false;

    return hasBottomSupport(x, y, width, height, rack, excludeProduct);
};

function hasBottomSupport(x, y, width, height, rack, excludeProduct = null) {
    const rackLeft = parseInt(rack.style.left);
    const rackTop = parseInt(rack.style.top);
    const rackHeight = parseInt(rack.style.height);
    const relativeY = y - rackTop;
    const bottom = relativeY + height;

    // Check if the product is at the bottom of the rack
    if (bottom === rackHeight) {
        return true;
    }

    // Get all products in the same rack that could potentially provide support
    const supportingProducts = products.filter(product => {
        if (product === excludeProduct || product.dataset.rackNumber !== rack.dataset.rackNumber) {
            return false;
        }

        const prodLeft = parseInt(product.style.left) - rackLeft;
        const prodRight = prodLeft + parseInt(product.style.width);
        const prodTop = parseInt(product.style.top) - rackTop;
        const relativeX = x - rackLeft;
        const productRight = relativeX + width;

        // Check if the product is directly below and there's any horizontal overlap
        return prodTop === bottom &&
            !(prodRight <= relativeX || prodLeft >= productRight);
    });

    if (supportingProducts.length === 0) {
        return false;
    }

    // Calculate total supported width
    let supportedRanges = supportingProducts.map(product => {
        const prodLeft = parseInt(product.style.left) - rackLeft;
        return {
            start: Math.max(prodLeft, x - rackLeft),
            end: Math.min(prodLeft + parseInt(product.style.width), x - rackLeft + width)
        };
    });

    // Sort ranges by start position
    supportedRanges.sort((a, b) => a.start - b.start);

    // Merge overlapping ranges
    let mergedRanges = [];
    let currentRange = supportedRanges[0];

    for (let i = 1; i < supportedRanges.length; i++) {
        if (supportedRanges[i].start <= currentRange.end) {
            currentRange.end = Math.max(currentRange.end, supportedRanges[i].end);
        } else {
            mergedRanges.push(currentRange);
            currentRange = supportedRanges[i];
        }
    }
    mergedRanges.push(currentRange);

    // Check if merged ranges cover the entire width
    const productStart = x - rackLeft;
    const productEnd = productStart + width;

    return mergedRanges.some(range =>
        range.start <= productStart && range.end >= productEnd
    );
};

function findProductsAbove(product, rack) {
    if (!product || !rack) return [];

    const productTop = parseInt(product.style.top);
    const productLeft = parseInt(product.style.left);
    const productRight = productLeft + parseInt(product.style.width);
    const rackNumber = product.dataset.rackNumber;

    return products?.filter(p => {
        if (p === product || p.dataset.rackNumber !== rackNumber) {
            return false;
        }

        const pBottom = parseInt(p.style.top) + parseInt(p.style.height);
        const pLeft = parseInt(p.style.left);
        const pRight = pLeft + parseInt(p.style.width);

        // Check if the product is directly above and has any horizontal overlap
        const isDirectlyAbove = pBottom === productTop;
        const hasHorizontalOverlap = !(pRight <= productLeft || pLeft >= productRight);
        const isWithinRackBounds = pLeft >= parseInt(rack.style.left) &&
            pRight <= (parseInt(rack.style.left) + currentRackWidth);

        return isDirectlyAbove && hasHorizontalOverlap && isWithinRackBounds;
    });
};

function applyGravityRecursively(products, rack, visited = new Set()) {
    if (!products.length) return;

    let anyMoved = false;
    products?.forEach(product => {
        if (visited.has(product)) return;
        visited.add(product);

        const currentY = parseInt(product.style.top);
        const lowestY = findLowestValidPosition(product, rack);

        if (lowestY !== null && lowestY > currentY) {
            product.style.top = `${lowestY}px`;
            anyMoved = true;

            // Find and update any products that were supported by this one
            const productsAbove = findProductsAbove(product, rack);
            if (productsAbove.length > 0) {
                applyGravityRecursively(productsAbove, rack, visited);
            }
        }
    });

    // If any product moved, do another pass to ensure all affected products are properly placed
    if (anyMoved) {
        const allRackProducts = products.filter(p =>
            p.dataset.rackNumber === rack.dataset.rackNumber &&
            !visited.has(p)
        );
        applyGravityRecursively(allRackProducts, rack, visited);
    }
};

function removeSelectedProduct() {
    if (selectedProduct) {
        const rackNumber = parseInt(selectedProduct.dataset.rackNumber);
        const rack = getRackByNumber(rackNumber);

        // Find products that might be affected before removing the selected product
        const productsAbove = findProductsAbove(selectedProduct, rack);

        // Remove the product
        const index = products?.indexOf(selectedProduct);
        if (index > -1) {
            products?.splice(index, 1);
            selectedProduct.remove();
            selectedProduct = null;
            removeProductBtn.style.display = "none";
        };


        // Apply gravity to affected products
        applyGravityRecursively(productsAbove, rack);
        saveGridState();
    }
};

function hasProductsAbove(product, rack) {
    if (!product || !rack) return false;

    const productTop = parseInt(product.style.top);
    const productLeft = parseInt(product.style.left);
    const productRight = productLeft + parseInt(product.style.width);
    const rackNumber = product.dataset.rackNumber;

    return products?.some(p => {
        if (p === product || p.dataset.rackNumber !== rackNumber) {
            return false;
        }

        const pBottom = parseInt(p.style.top) + parseInt(p.style.height);
        const pLeft = parseInt(p.style.left);
        const pRight = pLeft + parseInt(p.style.width);

        // Check if the product is directly above and has any horizontal overlap
        return pBottom === productTop &&
            !(pRight <= productLeft || pLeft >= productRight);
    });
};

function setupProductEventListeners(product) {
    product.addEventListener("click", () => {
        const rackNumber = parseInt(product.dataset.rackNumber);
        const rack = getRackByNumber(rackNumber);

        if (selectedProduct === product) {
            // Deselect it
            product.style.border = 0;
            selectedProduct = null;
            removeProductBtn.style.display = 'none';
        } else {
            // Check if the product has items above it
            if (hasProductsAbove(product, rack)) {
                // Cannot select products with items above
                return;
            }

            // If a different product was previously selected, reset its style
            if (selectedProduct) {
                selectedProduct.style.border = 0;
            }
            // Select the clicked product
            selectedProduct = product;
            product.style.border = "1.5px solid red";
            removeProductBtn.style.display = 'flex';
        }
    });

    product.addEventListener("dragstart", (e) => {
        currentDraggedProduct = product;
        product.classList.add("dragging");
        e.dataTransfer.setData("text/plain", "");

        lastValidPosition = {
            x: parseInt(product.style.left),
            y: parseInt(product.style.top),
            rackNumber: product.dataset.rackNumber
        };
    });

    product.addEventListener("dragend", handleProductDragEnd);
};

function handleProductDragEnd(e) {
    e.preventDefault();
    if (!currentDraggedProduct || currentDraggedProduct.isTemplate) return;

    const rect = gridContainer.getBoundingClientRect();
    const x = Math.round((e.clientX - rect.left + gridContainer.scrollLeft) / 10) * 10;
    const y = Math.round((e.clientY - rect.top + gridContainer.scrollTop) / 10) * 10;

    // Store original position information
    const originalRackNumber = parseInt(currentDraggedProduct.dataset.rackNumber);
    const originalRack = getRackByNumber(originalRackNumber);
    
    // Ensure product_id is preserved
    const productId = currentDraggedProduct.dataset.product_id;
    const imageLink = currentDraggedProduct.dataset.image_link;

    // Get the new rack and position
    const newRack = findRackAtPosition(x, y);
    const closestPosition = findClosestValidPosition(x, y);

    if (newRack && closestPosition) {
        const newRackNumber = parseInt(newRack.dataset.rackNumber);

        // Move product to new position
        currentDraggedProduct.style.left = `${closestPosition.x}px`;
        currentDraggedProduct.style.top = `${closestPosition.y}px`;
        currentDraggedProduct.dataset.rackNumber = newRackNumber;
        
        // Ensure product_id and image_link are preserved
        currentDraggedProduct.dataset.product_id = productId;
        currentDraggedProduct.dataset.image_link = imageLink;

        // If rack changed, apply gravity to both racks
        if (originalRackNumber !== newRackNumber) {
            const originalRackProducts = products?.filter(p =>
                parseInt(p.dataset.rackNumber) === originalRackNumber &&
                p !== currentDraggedProduct
            );

            // Apply gravity to original rack
            originalRackProducts.sort((a, b) =>
                parseInt(a.style.top) - parseInt(b.style.top)
            ).forEach(product => {
                const lowestY = findLowestValidPosition(product, originalRack);
                if (lowestY !== null) {
                    product.style.top = `${lowestY}px`;
                }
            });
        }

        // Apply gravity to destination rack
        const destinationRackProducts = products?.filter(p =>
            parseInt(p.dataset.rackNumber) === newRackNumber
        );

        destinationRackProducts.sort((a, b) =>
            parseInt(a.style.top) - parseInt(b.style.top)
        ).forEach(product => {
            const lowestY = findLowestValidPosition(product, newRack);
            if (lowestY !== null) {
                product.style.top = `${lowestY}px`;
            }
        });

        lastValidPosition = {
            x: closestPosition.x,
            y: closestPosition.y,
            rackNumber: newRackNumber
        };
    } else if (lastValidPosition) {
        // Revert to last valid position
        currentDraggedProduct.style.left = `${lastValidPosition.x}px`;
        currentDraggedProduct.style.top = `${lastValidPosition.y}px`;
        currentDraggedProduct.dataset.rackNumber = lastValidPosition.rackNumber;
        
        // Ensure product_id and image_link are preserved when reverting
        currentDraggedProduct.dataset.product_id = productId;
        currentDraggedProduct.dataset.image_link = imageLink;

        const currentRack = getRackByNumber(parseInt(lastValidPosition.rackNumber));
        applyGravityToRack(parseInt(lastValidPosition.rackNumber));
    }

    currentDraggedProduct.classList.remove('dragging');
    currentDraggedProduct.classList.remove('invalid');
    currentDraggedProduct = null;
    clearValidPositions();
    
    // Save grid state after drag operation
    saveGridState();
};

function findRackAtPosition(x, y) {
    return racks.find(rack => {
        const rackLeft = parseInt(rack.style.left);
        const rackTop = parseInt(rack.style.top);
        const rackWidth = parseInt(rack.style.width);  // Use actual rack width
        const rackHeight = parseInt(rack.style.height); // Use actual rack height

        return x >= rackLeft &&
            x < rackLeft + rackWidth &&  // Check against actual rack width
            y >= rackTop &&
            y < rackTop + rackHeight;    // Check against actual rack height
    });
};

function applyGravityToRack(rackNumber) {
    const rack = getRackByNumber(rackNumber);
    if (!rack) return;

    // Get all products in this rack
    const rackProducts = products?.filter(p =>
        parseInt(p.dataset.rackNumber) === rackNumber
    );

    // Sort products by vertical position (top to bottom)
    rackProducts?.sort((a, b) => parseInt(a.style.top) - parseInt(b.style.top));

    // Apply gravity to each product
    let moved;
    do {
        moved = false;
        for (const product of rackProducts) {
            const currentY = parseInt(product.style.top);
            const lowestY = findLowestValidPosition(product, rack);

            if (lowestY !== null && lowestY > currentY) {
                product.style.top = `${lowestY}px`;
                moved = true;
            }
        }
    } while (moved);
};

function findLowestValidPosition(product, rack) {
    const width = parseInt(product.style.width);
    const height = parseInt(product.style.height);
    const currentX = parseInt(product.style.left);
    const rackTop = parseInt(rack.style.top);
    const rackBottom = rackTop + parseInt(rack.style.height);

    // Try positions from bottom to top
    for (let y = rackBottom - height; y >= rackTop; y -= 10) {
        if (isValidPosition(currentX, y, width, height, rack, product)) {
            return y;
        }
    }
    return null;
};

function setupAutoSave() {
    gridContainer.addEventListener('dragend', (e) => {
        if (!currentDraggedProduct?.isTemplate) {
            setTimeout(saveGridState, 100);
        }
    });
};

function checkOverlap(rect1, rect2) {
    return !(rect1.right <= rect2.left ||
        rect1.left >= rect2.right ||
        rect1.bottom <= rect2.top ||
        rect1.top >= rect2.bottom);
};

function createProductInRack(width, height, x, y, rackNumber, imageLink, productId) {
    const product = document.createElement("div");
    product.classList.add("product");
    product.draggable = true;
    product.dataset.product_id = productId;
    product.dataset.rackNumber = rackNumber;
    product.dataset.image_link = imageLink;
    product.style.width = `${width}px`;
    product.style.height = `${height}px`;
    product.style.left = `${x}px`;
    product.style.top = `${y}px`;

    // Create an image element instead of text
    const productImage = document.createElement("img");
    productImage.src = imageLink;
    productImage.style.width = '100%';
    productImage.style.height = '100%';
    productImage.style.objectFit = 'cover';

    product.appendChild(productImage);

    setupProductEventListeners(product);

    gridContainer.appendChild(product);
    products.push(product);
    applyGravityToRack(rackNumber);
};

// ****************** Event Listeners ******************* //
document.getElementById("exportGridBtn").addEventListener('click', () => {
    if (!isGridCreated) {
        alert('Please create a grid first');
        return;
    }
    exportGridAsJson();
});

document.getElementById("importGridInput").addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (file) { importGridFromJson(file); }
});

document.getElementById("importGridBtn").addEventListener('click', () => {
    document.getElementById("importGridInput").click();
});

createGridBtn.addEventListener('click', () => { createGridModal.style.display = 'flex' });

closeGridModalBtn.addEventListener('click', () => { createGridModal.style.display = 'none' });

addRackBtn.addEventListener('click', () => { createRackModal.style.display = 'flex' });

closeRackModalBtn.addEventListener('click', () => { createRackModal.style.display = 'none' });

document.getElementById('createGridModalBtn').addEventListener('click', handleCreateGrid);

document.getElementById('createRackModalBtn').addEventListener('click', handleAddRack);

addProductBtn.addEventListener("click", () => {
    inputProductId.value = '';
    productName.value = '';
    productHeight.value = '';
    productWidth.value = '';
    document.getElementById('productImageInput').value = '';
    createProductModal.style.display = "flex";
});

closeProductModalBtn.addEventListener("click", () => {
    createProductModal.style.display = "none";
});

createProductModalBtn.addEventListener("click", () => {
    createProduct();
});

removeProductBtn.addEventListener("click", () => {
    removeSelectedProduct();
});

document.addEventListener("keydown", (event) => {
    if (selectedProduct && event.key === "Enter") {
        console.log("enter")
        removeSelectedProduct();
    }
});

document.addEventListener('DOMContentLoaded', async () => {
    await getAllProducts();
    await loadGridState();
    setupAutoSave();
});

gridContainer.addEventListener("dragover", (e) => {
    e.preventDefault();
    if (!currentDraggedProduct) return;

    const rect = gridContainer.getBoundingClientRect();
    const x = Math.round((e.clientX - rect.left + gridContainer.scrollLeft) / 10) * 10;
    const y = Math.round((e.clientY - rect.top + gridContainer.scrollTop) / 10) * 10;

    const width = currentDraggedProduct.isTemplate ?
        currentDraggedProduct.width :
        parseInt(currentDraggedProduct.style.width);
    const height = currentDraggedProduct.isTemplate ?
        currentDraggedProduct.height :
        parseInt(currentDraggedProduct.style.height);

    const rack = findRackAtPosition(x, y);

    clearValidPositions();

    if (rack) {
        // Use the actual rack dimensions from the rack element
        const rackLeft = parseInt(rack.style.left);
        const rackTop = parseInt(rack.style.top);
        const actualRackWidth = parseInt(rack.style.width);
        const actualRackHeight = parseInt(rack.style.height);

        // Loop through all possible positions using the actual rack width
        for (let posY = rackTop; posY <= rackTop + actualRackHeight - height; posY += 10) {
            for (let posX = rackLeft; posX <= rackLeft + actualRackWidth - width; posX += 10) {
                // Check if the position is valid within the actual rack dimensions
                if (posX + width <= rackLeft + actualRackWidth && // Ensure product fits within rack width
                    isValidPosition(posX, posY, width, height, rack, currentDraggedProduct.isTemplate ? null : currentDraggedProduct)) {
                    showValidPosition(posX, posY, width, height);
                }
            }
        }

        if (!currentDraggedProduct.isTemplate) {
            const isValid = validPositions.some(pos => pos.x === x && pos.y === y);
            currentDraggedProduct.classList.toggle("invalid", !isValid);
            currentDraggedProduct.style.left = `${x}px`;
            currentDraggedProduct.style.top = `${y}px`;
        }
    } else if (!currentDraggedProduct.isTemplate) {
        currentDraggedProduct.classList.add("invalid");
        currentDraggedProduct.style.left = `${x}px`;
        currentDraggedProduct.style.top = `${y}px`;
    }
});

gridContainer.addEventListener("drop", (e) => {
    e.preventDefault();
    if (!currentDraggedProduct) return;

    const rect = gridContainer.getBoundingClientRect();
    const x = Math.round((e.clientX - rect.left + gridContainer.scrollLeft) / 10) * 10;
    const y = Math.round((e.clientY - rect.top + gridContainer.scrollTop) / 10) * 10;

    const rack = findRackAtPosition(x, y);
    const closestPosition = findClosestValidPosition(x, y);

    if (currentDraggedProduct.isTemplate) {
        if (rack && closestPosition) {
            createProductInRack(
                currentDraggedProduct.width,
                currentDraggedProduct.height,
                closestPosition.x,
                closestPosition.y,
                rack.dataset.rackNumber,
                currentDraggedProduct.image_link,
                currentDraggedProduct.product_id
            );
            setTimeout(saveGridState, 100);
        }
    } else {
        handleProductDragEnd(e);
    }

    currentDraggedProduct = null;
    clearValidPositions();
});