document.addEventListener("DOMContentLoaded", () => {
  const canvas = new fabric.Canvas("canvas", {
    width: parseInt(
      document.getElementById("canvas").getAttribute("width"),
      10
    ),
    height: parseInt(
      document.getElementById("canvas").getAttribute("height"),
      10
    ),
    selection: false, // Disable group selection for better individual control
  });
  const canvas2 = new fabric.Canvas("canvas2", {
    width: parseInt(
      document.getElementById("canvas2").getAttribute("width"),
      10
    ),
    height: parseInt(
      document.getElementById("canvas2").getAttribute("height"),
      10
    ),
    selection: false, // Disable group selection for better individual control
    hoverCursor: "pointer",
    backgroundColor: "transparent", // Make sure the background is transparent
  });

  const gridSize = 50; // Grid size in pixels

  // Draw grid on the first canvas
  for (let i = 0; i <= canvas.width; i += gridSize) {
    canvas.add(
      new fabric.Line([i, 0, i, canvas.height], {
        stroke: "#ccc",
        selectable: false,
      })
    );
  }
  for (let i = 0; i <= canvas.height; i += gridSize) {
    canvas.add(
      new fabric.Line([0, i, canvas.width, i], {
        stroke: "#ccc",
        selectable: false,
      })
    );
  }

  // Draw grid on the second canvas
  for (let i = 0; i <= canvas2.width; i += gridSize) {
    canvas2.add(
      new fabric.Line([i, 0, i, canvas2.height], {
        stroke: "#ccc",
        selectable: false,
      })
    );
  }
  for (let i = 0; i <= canvas2.height; i += gridSize) {
    canvas2.add(
      new fabric.Line([0, i, canvas2.width, i], {
        stroke: "#ccc",
        selectable: false,
      })
    );
  }
  function loadContainerImages(containerId) {
    fetch(`/api/getContainer/${containerId}`)
      .then((response) => response.json())
      .then((data) => {
        if (data && data.json) {
          const canvasData = JSON.parse(data.json);

          // Loop through each object in the container data and load images or shapes
          canvasData.objects.forEach((obj) => {
            if (obj.type === "image") {
              // Load image from URL into canvas2
              fabric.Image.fromURL(obj.src, (img) => {
                img.set({
                  left: obj.left,
                  top: obj.top,
                  width: obj.width,
                  height: obj.height,
                  scaleX: obj.scaleX,
                  scaleY: obj.scaleY,
                });
                canvas2.add(img); // Add image to canvas2
              });
            } else if (obj.type === "rect") {
              // Load rectangle (or other objects) onto canvas2
              const rect = new fabric.Rect({
                left: obj.left,
                top: obj.top,
                width: obj.width,
                height: obj.height,
                fill: obj.fill,
                scaleX: obj.scaleX,
                scaleY: obj.scaleY,
              });
              canvas2.add(rect);
            }
          });

          canvas2.renderAll(); // Re-render the canvas after adding objects
        } else {
          console.warn("Failed to load container data.");
          console.log("daaa : " + JSON.stringify(data));
        }
      })
      .catch((error) => {
        console.error("Error loading container data:", error);
        alert("Error loading container data.");
      });
  }

  if (initialCanvasData) {
    canvas.loadFromJSON(initialCanvasData, canvas.renderAll.bind(canvas));
    canvas2.loadFromJSON(initialCanvasData, canvas2.renderAll.bind(canvas2));
    console.log("canvasss : " + JSON.stringify(initialCanvasData));
    const parsedData = JSON.parse(initialCanvasData);
    parsedData.objects.forEach((obj) => {
      if (obj.id && obj.id.startsWith("container_")) {
        // Ensure the ID is a container ID
        loadContainerImages(obj.id); // Pass the container ID to loadContainerImages
        console.log("asda : " + obj.id);
      }
    });
  }
  // Event listener for mouse down to detect if the clicked object is an image
  canvas.on("mouse:down", function (e) {
    const selectedObject = e.target;

    // Check if the selected object is an image
    if (selectedObject && selectedObject.type === "image") {
      console.log("Image selected:", selectedObject); // Log to verify if it's selected
      showDeleteButton(selectedObject);
    } else {
      // Hide the delete button if a non-image object is selected
      const deleteButton = document.getElementById("deleteButton");
      deleteButton.style.display = "none";
    }
  });

  document.getElementById("deleteButton").addEventListener("click", () => {
    const selectedObject = canvas.getActiveObject();
    if (selectedObject) {
      canvas.remove(selectedObject);
      // Hide the delete button after deleting the image
      document.getElementById("deleteButton").style.display = "none";
    }
  });

  // Update the button position when the image is moved
  canvas.on("object:moving", function (e) {
    const selectedObject = e.target;
    if (selectedObject && selectedObject.type === "image") {
      showDeleteButton(selectedObject);
    }
  });

  // Handle the drag event for adding containers to canvas
  const draggableContainers = document.querySelectorAll(".draggable-container");
  draggableContainers.forEach((container) => {
    container.addEventListener("dragstart", (e) => {
      e.dataTransfer.setData("containerId", e.target.id); // Store the container id in dataTransfer
    });
  });

  const canvasWrapper = document.querySelector(".canvas-wrapper");
  canvasWrapper.addEventListener("dragover", (e) => {
    e.preventDefault(); // Allow drop
  });

  canvasWrapper.addEventListener("drop", (e) => {
    e.preventDefault();
    const containerId = e.dataTransfer.getData("containerId");
    const draggedContainer = document.getElementById(containerId);

    if (draggedContainer) {
      const uniqueId = `container_${Date.now()}`; // Generate a unique ID
      const rect = new fabric.Rect({
        left: e.offsetX,
        top: e.offsetY,
        fill: "#3498db",
        width: 100,
        height: 100,
        hasBorders: true,
        hasControls: true,
        selectable: true,
        id: uniqueId, // Assign the unique ID
      });

      canvas.add(rect);
    }
  });

  // Button to add a rectangle (for demonstration purposes)
  document.getElementById("addRectangleBtn").addEventListener("click", () => {
    const rect = new fabric.Rect({
      left: 100,
      top: 100,
      fill: "red",
      width: 60,
      height: 70,
      hasBorders: true,
      hasControls: true,
      selectable: true,
    });
    canvas.add(rect);
  });

  // Save canvas data
  document.getElementById("saveCanvasBtn").addEventListener("click", () => {
    const canvasObjects = canvas.getObjects().map((obj) => {
      return {
        ...obj.toObject(),
        id: obj.id || null, // Include the object ID if available
      };
    });

    const canvasJson = JSON.stringify({ objects: canvasObjects });
    fetch(`/api/saveCanvas/${document.location.pathname.split("/")[2]}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ json: canvasJson }),
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.success) {
          alert("Canvas saved successfully!");
        }
      });
  });

  function redirectToContainerPage(container) {
    const width = container.width * container.scaleX;
    const height = container.height * container.scaleY;
    const id = container.id;
    const newPageUrl = `/container?width=${width}&height=${height}&id=${id}`;
    window.location.href = newPageUrl;
  }

  function showDeleteButton(selectedObject) {
    const deleteButton = document.getElementById("deleteButton");
    const openCanvas = document.getElementById("openCanvas");
    openCanvas.addEventListener("click", () => {
      const selectedObject = canvas.getActiveObject();
      if (selectedObject && selectedObject.type === "rect") {
        redirectToContainerPage(selectedObject);
      } else {
        alert("Please select a container to open.");
      }
    });
    if (selectedObject && selectedObject.type === "rect") {
      const buttonOffset = 10;
      const objectPosition = selectedObject.getBoundingRect();

      deleteButton.style.display = "block";
      openCanvas.style.display = "block";
      deleteButton.style.left = `${
        objectPosition.left + objectPosition.width + buttonOffset
      }px`;
      deleteButton.style.top = `${objectPosition.top + buttonOffset}px`;
    } else {
      deleteButton.style.display = "none";
      openCanvas.style.display = "none";
    }
  }

  canvas.on("mouse:down", function (e) {
    const selectedObject = e.target;

    // Check if the selected object is an image or a rect (container)
    if (
      selectedObject &&
      (selectedObject.type === "image" || selectedObject.type === "rect")
    ) {
      console.log("Object selected:", selectedObject); // Log to verify if it's selected
      showDeleteButton(selectedObject);
    } else {
      // Hide the delete button if a non-image, non-container object is selected
      const deleteButton = document.getElementById("deleteButton");
      const openCanvas = document.getElementById("openCanvas");
      deleteButton.style.display = "none";
      openCanvas.style.display = "none";
    }
  });

  // Restrict dragging objects outside the canvas and handle snapping
  canvas.on("object:moving", (e) => {
    const obj = e.target;
    const boundingRect = obj.getBoundingRect(true);
    const canvasWidth = canvas.getWidth();
    const canvasHeight = canvas.getHeight();

    // Prevent dragging outside canvas horizontally
    if (boundingRect.left < 0) obj.left = 0;
    if (boundingRect.left + boundingRect.width > canvasWidth) {
      obj.left = canvasWidth - boundingRect.width;
    }

    // Prevent dragging outside canvas vertically
    if (boundingRect.top < 0) obj.top = 0;
    if (boundingRect.top + boundingRect.height > canvasHeight) {
      obj.top = canvasHeight - boundingRect.height;
    }

    // Snapping to grid
    obj.left = Math.round(obj.left / gridSize) * gridSize;
    obj.top = Math.round(obj.top / gridSize) * gridSize;

    // Prevent overlapping
    canvas.forEachObject((other) => {
      if (other === obj) return;
      const otherBounds = other.getBoundingRect();

      if (
        boundingRect.left < otherBounds.left + otherBounds.width &&
        boundingRect.left + boundingRect.width > otherBounds.left &&
        boundingRect.top < otherBounds.top + otherBounds.height &&
        boundingRect.top + boundingRect.height > otherBounds.top
      ) {
        // Snap to avoid overlap
        if (boundingRect.left < otherBounds.left) {
          obj.left = otherBounds.left - boundingRect.width;
        } else if (boundingRect.left > otherBounds.left) {
          obj.left = otherBounds.left + otherBounds.width;
        }

        if (boundingRect.top < otherBounds.top) {
          obj.top = otherBounds.top - boundingRect.height;
        } else if (boundingRect.top > otherBounds.top) {
          obj.top = otherBounds.top + otherBounds.height;
        }
      }
    });

    obj.setCoords(); // Update object's coordinates
  });
});
