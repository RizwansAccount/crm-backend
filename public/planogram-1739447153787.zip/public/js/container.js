const urlParams = new URLSearchParams(window.location.search);
const containerWidth = parseFloat(urlParams.get('width'));
const containerHeight = parseFloat(urlParams.get('height'));
const containerId = urlParams.get('id');

const canvas = new fabric.Canvas('canvas', {
    width: containerWidth,
    height: containerHeight,
});
document.addEventListener('DOMContentLoaded', () => {
    fetch(`/api/getContainer/${containerId}`)
        .then(response => response.json())
        .then(data => {
            if (data && data.json) {
                console.log("Canvas data loaded:", data.json);

                const canvasData = JSON.parse(data.json);
                console.log("Parsed Canvas Data:", canvasData);

                canvas.loadFromJSON(canvasData, () => {
                    console.log("Canvas loaded");
                    canvas.renderAll();
                    canvas.getObjects('image').forEach(img => {
                        img.set({
                            lockScalingX: true,
                            lockScalingY: true,
                            hasControls: false,   // Hide the corner handles (stretch block)
                            hasBorders: false,
                        });
                    });

                    // Check if objects exist and display uploaded images
                    if (canvasData.objects && Array.isArray(canvasData.objects)) {
                        //displayUploadedImages(canvasData.objects);
                    } else {
                        console.warn("No objects found in the parsed data.");
                    }
                });
            }
        })
        .catch(error => {
            console.error("Error loading canvas data:", error);
        });
});

function displayUploadedImages(objects) {
    objects.forEach(obj => {
        if (obj.type === 'image' && obj.src) {
            console.log("Processing image:", obj);
            const imgElement = document.createElement('img');
            imgElement.src = obj.src;
            imgElement.alt = 'Uploaded Image';
            imgElement.classList.add('thumbnail');
            imgElement.addEventListener('click', () => {
                const imgObj = new Image();
                imgObj.src = obj.src;
                imgObj.onload = function () {
                    const image = new fabric.Image(imgObj);
                    image.set({
                        left: 100,
                        top: 100,
                        scaleX: obj.scaleX,
                        scaleY: obj.scaleY
                    });
                    canvas.add(image);
                };
            });
            document.getElementById('uploadedImages').appendChild(imgElement);
        }
    });
}


canvas.on('selection:created', function (e) {
    const selectedObject = e.target;
    showDeleteButton(selectedObject);
});

canvas.on('selection:updated', function (e) {
    const selectedObject = e.target;
    showDeleteButton(selectedObject);
});
canvas.on('selection:cleared', function () {
    const deleteButton = document.getElementById('deleteButton');
    deleteButton.style.display = 'none';
});

function showDeleteButton(selectedObject) {
    const deleteButton = document.getElementById('deleteButton');
    if (selectedObject) {
        deleteButton.style.display = 'block';
        deleteButton.style.top = `${selectedObject.top - 10}px`;
        deleteButton.style.left = `${selectedObject.left + selectedObject.width + 10}px`;
    } else {
        deleteButton.style.display = 'none';
    }
}
// Shape drag-and-drop functionality
document.querySelectorAll('#shapeButtons img').forEach(shape => {
    shape.addEventListener('dragstart', (e) => {
        e.dataTransfer.setData('shape', e.target.alt);
    });
});

document.querySelectorAll('#images img').forEach(image => {
    image.addEventListener('dragstart', (e) => {
        e.dataTransfer.setData('imageSrc', image.src); // Store the image source in the transfer object
    });
});

document.getElementById('deleteButton').addEventListener('click', () => {
    const selectedObject = canvas.getActiveObject();
    if (selectedObject) {
        canvas.remove(selectedObject);
        // Hide the delete button after deleting the image
        document.getElementById('deleteButton').style.display = 'none';
    }
});

canvas.upperCanvasEl.addEventListener('dragover', (e) => {
    e.preventDefault(); // Necessary to allow the drop
});

canvas.upperCanvasEl.addEventListener('drop', (e) => {
    e.preventDefault();

    // Get the image source from the dataTransfer object
    const imageSrc = e.dataTransfer.getData('imageSrc');
    const position = canvas.getPointer(e);

    if (imageSrc) {
        const imgObj = new Image();
        imgObj.src = imageSrc;
        imgObj.onload = function () {
            // Check if the image is larger than the canvas size
            const canvasWidth = canvas.getWidth();
            const canvasHeight = canvas.getHeight();

            if (imgObj.width > canvasWidth || imgObj.height > canvasHeight) {
                // Alert if image is larger than the canvas
                alert('The product image size is greater than the rack size (canvas).');
                return; // Don't add the image to the canvas
            }

            // If the image fits, add it to the canvas
            const image = new fabric.Image(imgObj);
            image.set({
                left: position.x,
                top: position.y,
                lockScalingX: true, // Disable resizing in the X direction
                lockScalingY: true,
                hasControls: false,   // Hide the corner handles (stretch block)
                hasBorders: false,
            });
            canvas.add(image);
        };
    }
});



// Image upload with drag and drop
document.getElementById('addImageButton').addEventListener('click', () => {
    document.getElementById('imageUpload').click();
});

document.getElementById('imageUpload').addEventListener('change', (event) => {
    const file = event.target.files[0];
    if (file.type !== 'image/svg+xml') {
        alert('Please upload an SVG file.');
        return;
    }
    const reader = new FileReader();
    reader.onload = function (event) {
        const imgObj = new Image();
        imgObj.src = event.target.result;
        imgObj.onload = function () {
            const image = new fabric.Image(imgObj);
            const scale = Math.min(canvas.width / imgObj.width, canvas.height / imgObj.height);
            image.set({
                left: 100,
                top: 100,
                scaleX: scale,
                scaleY: scale
            });

            canvas.add(image);

            // Create image thumbnail and display in the sidebar
            const imgElement = document.createElement('img');
            imgElement.src = event.target.result;
            imgElement.alt = 'Uploaded Image';
            imgElement.classList.add('thumbnail');
            imgElement.draggable = true; // Enable dragging
            imgElement.addEventListener('dragstart', (e) => {
                e.dataTransfer.setData('imageSrc', imgObj.src);
            });
            imgElement.addEventListener('click', () => {
                // Add the image to canvas when clicked on the thumbnail
                const imgClone = new fabric.Image(imgObj);
                imgClone.set({
                    left: 100,
                    top: 100,
                    scaleX: scale,
                    scaleY: scale
                });
                canvas.add(imgClone);
            });

            // Add the thumbnail to the sidebar
            document.getElementById('uploadedImages').appendChild(imgElement);
        };
    };
    reader.readAsDataURL(event.target.files[0]);
});
// Save canvas as JSON
document.getElementById('saveCanvasBtn').addEventListener('click', () => {
    const canvasJson = JSON.stringify(canvas);
    fetch(`/api/saveContainer`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ id: containerId, json: canvasJson })
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Canvas saved successfully!');
            }
        });
});

canvas.on('object:moving', (e) => {
    const obj = e.target;
    const boundingRect = obj.getBoundingRect(true);
    const canvasWidth = canvas.getWidth();
    const canvasHeight = canvas.getHeight();

    // Prevent dragging outside canvas boundaries
    if (boundingRect.left < 0) obj.left = 0;
    if (boundingRect.top < 0) obj.top = 0;
    if (boundingRect.left + boundingRect.width > canvasWidth) {
        obj.left = canvasWidth - boundingRect.width;
    }
    if (boundingRect.top + boundingRect.height > canvasHeight) {
        obj.top = canvasHeight - boundingRect.height;
    }

    // Detect Overlap but don't apply repositioning here to avoid shaking
    let isOverlapping = false;
    canvas.forEachObject((other) => {
        if (other === obj) return;
        const otherBounds = other.getBoundingRect();

        if (
            boundingRect.left < otherBounds.left + otherBounds.width &&
            boundingRect.left + boundingRect.width > otherBounds.left &&
            boundingRect.top < otherBounds.top + otherBounds.height &&
            boundingRect.top + boundingRect.height > otherBounds.top
        ) {
            isOverlapping = true;
        }
    });

    if (isOverlapping) {
        obj.set({ fill: 'red' }); // Indicate overlap with color change
    } else {
        obj.set({ fill: '#3498db' }); // Default color
    }

    obj.setCoords();
});
const gridSize = 20;

// Apply snapping & repositioning **only after** the object is dropped
canvas.on('object:moved', (e) => {
    const obj = e.target;

    // 1️⃣ Snapping to grid (adjusting position)
    obj.left = Math.round(obj.left / gridSize) * gridSize;
    obj.top = Math.round(obj.top / gridSize) * gridSize;

    // 2️⃣ Prevent going outside canvas bounds
    const boundingRect = obj.getBoundingRect(true);
    const canvasWidth = canvas.getWidth();
    const canvasHeight = canvas.getHeight();

    if (boundingRect.left < 0) obj.left = 0;
    if (boundingRect.top < 0) obj.top = 0;
    if (boundingRect.left + boundingRect.width > canvasWidth) {
        obj.left = canvasWidth - boundingRect.width;
    }
    if (boundingRect.top + boundingRect.height > canvasHeight) {
        obj.top = canvasHeight - boundingRect.height;
    }

    // 3️⃣ Check and reposition if overlapping
    let repositioned = false;
    canvas.forEachObject((other) => {
        if (other === obj) return;
        const otherBounds = other.getBoundingRect();
        const objBounds = obj.getBoundingRect();

        if (
            objBounds.left < otherBounds.left + otherBounds.width &&
            objBounds.left + objBounds.width > otherBounds.left &&
            objBounds.top < otherBounds.top + otherBounds.height &&
            objBounds.top + objBounds.height > otherBounds.top
        ) {
            repositioned = true;

            // Adjust position based on where the overlap is detected
            if (objBounds.left < otherBounds.left) {
                obj.left = otherBounds.left - objBounds.width;
            } else {
                obj.left = otherBounds.left + otherBounds.width;
            }

            if (objBounds.top < otherBounds.top) {
                obj.top = otherBounds.top - objBounds.height;
            } else {
                obj.top = otherBounds.top + otherBounds.height;
            }

            // 4️⃣ Ensure the new position is still inside canvas
            obj.left = Math.max(0, Math.min(obj.left, canvasWidth - objBounds.width));
            obj.top = Math.max(0, Math.min(obj.top, canvasHeight - objBounds.height));
        }
    });

    if (repositioned) {
        obj.set({ fill: 'orange' }); // Indicate repositioned due to overlap
    }

    obj.setCoords();
    canvas.renderAll();
});