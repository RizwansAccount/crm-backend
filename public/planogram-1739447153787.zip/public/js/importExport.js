
function exportShopAsJson(shopId) {
    fetch(`/api/shop/${shopId}`)
        .then(response => response.json())
        .then(data => {
            const jsonString = JSON.stringify(data, null, 2);
            const blob = new Blob([jsonString], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `shop_${shopId}.json`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        })
        .catch(error => {
            console.error('Error exporting shop as JSON:', error);
            alert('Error exporting shop as JSON.');
        });
}


function deleteShop(shopId) {
    if (confirm('Are you sure you want to delete this shop?')) {
        fetch(`/api/shop/${shopId}`, {
            method: 'DELETE',
        })
            .then(response => {
                if (response.ok) {
                    alert('Shop deleted successfully!');
                    location.reload(); // Refresh page to reflect the deletion
                } else {
                    alert('Error deleting shop.');
                }
            })
            .catch(error => {
                console.error('Error deleting shop:', error);
                alert('Error deleting shop.');
            });
    }
}

let selectedFile = null; // Store the selected file

function handleFileChange(event) {
    selectedFile = event.target.files[0];
}

async function importShop() {
    const shopName = document.getElementById("shopName").value.trim();

    if (!shopName) {
        alert("Please enter a shop name.");
        return;
    }

    if (!selectedFile) {
        alert("Please select a JSON file.");
        return;
    }

    const reader = new FileReader();
    reader.onload = async (e) => {
        try {

            let shopData = JSON.parse(e.target.result);

            // Ensure JSON structure
            if (typeof shopData !== "object") {
                throw new Error("Invalid JSON format.");
            }

            // Extract canvas details from the imported shop JSON
            const { canvas } = shopData;
            if (!canvas || !canvas.json) {
                throw new Error("Invalid canvas data in JSON.");
            }

            // Step 1: Create a new canvas in the database
            const canvasResponse = await fetch('/api/create-canvas', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    // json: canvas.json, // Use the existing canvas JSON structure
                    // width: canvas.width,
                    // height: canvas.height
                })
            });

            console.log('canvas canvas canvas:', canvasResponse);

        } catch (error) {
            console.error('Error importing shop:', error);
            alert('Error importing shop. Please check the JSON file.');
        }
    };
    reader.readAsText(selectedFile);
}
