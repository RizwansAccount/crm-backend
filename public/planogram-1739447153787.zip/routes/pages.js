import express from "express";
import Shop from "../models/Shop.js";
import Canvas from "../models/Canvas.js";
import User from "../models/User.js";

const router = express.Router();


// Login Page

router.get('/container', (req, res) => {
    const { width, height,id } = req.query;
    if (!req.isAuthenticated()) {
        return res.redirect('/login');
    }
    res.render('container', { width, height,id });
});
router.get('/', (req, res) => {
    // Check if the user is logged in (authenticated)
    if (req.isAuthenticated()) {
        return res.redirect('/shops');  // Redirect to the shops page if logged in
    }
    return res.redirect('/login');  // Redirect to the login page if not logged in
});

router.get('/login', (req, res) => {
  res.render('login', { message: req.flash('error') });
});

// Sign Up Page
router.get('/signup', (req, res) => {
  res.render('signup',{ message: req.flash('error') });
});

// Shop Creation Page
router.get('/shop', (req, res) => {
  if (!req.isAuthenticated()) {
    return res.redirect('/login');
  }
  res.render('shop', { user: req.user });
});

// User's Shops Page
router.get('/shops', async (req, res) => {
  if (!req.isAuthenticated()) {
    return res.redirect('/login');
  }
  const user = await User.findById(req.user._id).populate('shops');
  res.render('shops', { shops: user.shops });
});

// Canvas Page for a Specific Shop
router.get('/shop/:id', async (req, res) => {
  if (!req.isAuthenticated()) {
    return res.redirect('/login');
  }
  const shop = await Shop.findById(req.params.id).populate('canvas');
  res.render('index', { canvasData: shop.canvas.json, width: shop.width, height: shop.height });
});

// Logout Route
router.get('/logout', (req, res, next) => {
  req.logout(err => {
    if (err) {
      return next(err);
    }
    res.redirect('/login');
  });
});

export default router;
