import express from "express";
import passport from "passport";
import Shop from "../models/Shop.js";
import Canvas from "../models/Canvas.js";
import User from "../models/User.js";
import Container from "../models/Container.js";
import GridModel from "../models/grid.model.js";
import uploadFile from "../middleware/uploadFile.js";
import productModel from "../models/product.model.js";
import multer from "multer";

const router = express.Router();

// Create a New User
router.post("/signup", async (req, res) => {
  try {
    const existingUser = await User.findOne({ username: req.body.username });

    if (existingUser) {
      req.flash("error", "Email already exists!");
      return res.redirect("/signup");
    }

    // Create a new user if the email doesn't exist
    const newUser = new User({
      username: req.body.username,
      password: req.body.password,
    });

    await newUser.save();
    res.redirect("/login");
  } catch (err) {
    console.error(err);
    res.redirect("/signup");
  }
});

// Login Authentication (handled by Passport middleware)
router.post(
  "/login",
  passport.authenticate("local", {
    successRedirect: "/shops",
    failureRedirect: "/login",
    failureFlash: true,
  })
);

// Create a New Shop
router.post("/create-shop", async (req, res) => {
  if (!req.isAuthenticated()) {
    return res.redirect("/login");
  }
  const { name, width, height } = req.body;
  const newCanvas = new Canvas({ width, height, json: "{}" });
  await newCanvas.save();

  const newShop = new Shop({
    user: req.user._id,
    name,
    width,
    height,
    canvas: newCanvas._id,
  });
  await newShop.save();

  req.user.shops.push(newShop);
  await req.user.save();

  res.redirect(`/shop/${newShop._id}`);
});

const upload = multer({ storage: multer.memoryStorage() }); // Store file in memory

router.post("/import-shop", upload.single("shopJson"), async (req, res) => {
    if (!req.file) {
        return res.status(400).json({ error: "No file uploaded" });
    }

    try {
        // Convert uploaded file to JSON
        const importedShop = JSON.parse(req.file.buffer.toString());
        const name = req.body.shopName;
        const width = importedShop.canvas.width;
        const height = importedShop.canvas.height;
        const json = importedShop.canvas.json;

        // Parse JSON and Extract Container IDs
        const parsedJson = JSON.parse(json);
        const containerIds = parsedJson.objects.map(obj => obj.id);

        // Fetch all relevant grids from the DB
        const grids = await GridModel.find({ project_id: { $in: containerIds } });

        // 🔹 Duplicate Grids & Get New project_ids
        let gridMapping = {}; // Store old_id -> new_id mapping

        for (let grid of grids) {
            const newGrid = new GridModel({
                dimensions: grid.dimensions,
                project_id: `container_${Date.now()}`, // This will be updated later
                racks: grid.racks,
                products: grid.products,
                createdAt: new Date(),
                updatedAt: new Date()
            });

            await newGrid.save(); // Save the duplicated grid

            gridMapping[grid.project_id] = newGrid.project_id; // Map old_id -> new_id
        }

        console.log("Grid Mapping (Old to New IDs):", gridMapping);

        // 🔹 Replace project_ids in JSON
        parsedJson.objects.forEach(obj => {
            if (gridMapping[obj.id]) {
                obj.id = gridMapping[obj.id]; // Replace old project_id with new one
            }
        });

        // Convert updated JSON back to string
        const updatedJson = JSON.stringify(parsedJson);

        // Save new Canvas with updated JSON
        const newCanvas = new Canvas({ width, height, json: updatedJson });
        await newCanvas.save();

        // Save new Shop
        const newShop = new Shop({
            user: req.user._id,
            name,
            width,
            height,
            canvas: newCanvas._id,
        });
        await newShop.save();

        req.user.shops.push(newShop);
        await req.user.save();

        res.json({ success: true, newShop, gridMapping });
    } catch (error) {
        console.error("Error:", error);
        res.status(400).json({ error: "Invalid JSON format in file" });
    }
});


// Save Canvas Data
router.post("/saveCanvas/:id", async (req, res) => {
  const shop = await Shop.findById(req.params.id).populate("canvas");
  if (shop && shop.canvas) {
    shop.canvas.json = req.body.json;
    await shop.canvas.save();
    res.send({ success: true });
  } else {
    res.send({ success: false });
  }
});

router.post("/saveContainer", async (req, res) => {
  const { id, json } = req.body;

  if (!id || !json) {
    return res
      .status(400)
      .send({
        success: false,
        message: "Missing container ID or canvas data.",
      });
  }

  try {
    let container = await Container.findOne({ containerId: id });
    if (!container) {
      container = new Container({ containerId: id, json, width: 0, height: 0 });
    } else {
      container.json = json;
    }

    await container.save();
    res.send({ success: true, message: "Container saved successfully." });
  } catch (err) {
    console.error("Error saving canvas:", err);
    res.status(500).send({ success: false, message: "Failed to save canvas." });
  }
});

// Get Canvas Data by Container ID
router.get("/getContainer/:id", async (req, res) => {
  const { id } = req.params;

  try {
    const container = await Container.findOne({ containerId: id });

    if (container) {
      res.send({ success: true, json: container.json });
    } else {
      res
        .status(404)
        .send({
          success: false,
          message: "No canvas found for this container ID.",
        });
    }
  } catch (err) {
    console.error("Error retrieving canvas:", err);
    res
      .status(500)
      .send({ success: false, message: "Failed to retrieve canvas." });
  }
});

// Get Grid data Api
router.get("/grid/:projectId", async (req, res) => {
  try {
    const project_id = req.params.projectId;
    const data = await GridModel.findOne({ project_id });
    res.send({ success: true, data });
  } catch (error) {
    console.error(error);
  }
});

// Create Grid Api
router.post("/grid/create", async (req, res) => {
  try {
    const { project_id, racks, products, dimensions } = req.body;

    let grid = await GridModel.findOne({ project_id });

    if (grid) {
      grid.racks = racks;
      grid.products = products;
      grid.dimensions = dimensions;
      await grid.save();
    } else {
      grid = new GridModel({ project_id, racks, products, dimensions });
      await grid.save();
    }

    res.send({
      success: true,
      data: grid,
      message: "Grid saved successfully.",
    });
  } catch (error) {
    console.error(error);
  }
});

// Get All products Api
router.get("/product", async (req, res) => {
  try {
    const data = await productModel.find();
    res.send({ success: true, data, message: "products fetch succesfully" });
  } catch (error) {
    console.error(error);
  }
});

// Create Product Api
router.post("/product", uploadFile.single("file"), async (req, res) => {
  let body = {
    ...req.body,
    image_link: `${req.protocol}://${req.get("host")}/${req?.file?.path}`,
    image: req?.file?.path,
  };

  const product_id = body.product_id;

  const isProductAlreadyExist = await productModel.findOne({product_id});

  if(isProductAlreadyExist) {
    return res.status(404).send({success : false, message : "product already exist with this id"});
  }

  const data = await productModel.create(body);
  res.send({ success: true, data, message: "products fetch succesfully" });
});

// router.post('/import-shop', async (req, res) => {
//     if (!req.isAuthenticated()) {
//         return res.redirect('/login');
//     }

//     const { name, width, height, canvas, containers, grids } = req.body;

//     // Create a new canvas
//     const newCanvas = new Canvas({
//         width: canvas.width,
//         height: canvas.height,
//         json: canvas.json,
//     });
//     await newCanvas.save();

//     // Create a new shop
//     const newShop = new Shop({
//         user: req.user._id,
//         name,
//         width,
//         height,
//         canvas: newCanvas._id,
//     });
//     await newShop.save();

//     // Map to store old containerId to new containerId mappings
//     const containerIdMap = new Map();

//     // Save containers with new containerId
//     if (containers && containers.length > 0) {
//         for (const containerData of containers) {
//             const newContainerId = generateNewContainerId(); // Generate a new containerId
//             containerIdMap.set(containerData.containerId, newContainerId); // Store the mapping

//             const newContainer = new Container({
//                 containerId: newContainerId,
//                 json: containerData.json,
//                 width: containerData.width,
//                 height: containerData.height,
//             });
//             await newContainer.save();
//         }
//     }

//     // Save grids with updated project_id (containerId)
//     if (grids && grids.length > 0) {
//         for (const gridData of grids) {
//             const newProjectId = containerIdMap.get(gridData.project_id); // Get the new containerId
//             if (!newProjectId) {
//                 console.error(`No new containerId found for project_id: ${gridData.project_id}`);
//                 continue;
//             }

//             const newGrid = new GridModel({
//                 project_id: newProjectId,
//                 racks: gridData.racks,
//                 products: gridData.products,
//                 dimensions: gridData.dimensions,
//             });
//             await newGrid.save();
//         }
//     }

//     // Update the canvas JSON with new containerIds
//     if (canvas.json) {
//         const canvasJson = JSON.parse(canvas.json);
//         canvasJson.objects = canvasJson.objects.map(obj => {
//             if (obj.id && obj.id.startsWith('container_')) {
//                 obj.id = containerIdMap.get(obj.id) || obj.id; // Replace with new containerId
//             }
//             return obj;
//         });
//         newCanvas.json = JSON.stringify(canvasJson);
//         await newCanvas.save();
//     }

//     // Add the shop to the user's shops array
//     req.user.shops.push(newShop);
//     await req.user.save();

//     res.redirect(`/shop/${newShop._id}`);
// });

router.get("/shop/:id", async (req, res) => {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ error: "Unauthorized" });
  }

  try {
    const shop = await Shop.findById(req.params.id).populate("canvas");
    if (!shop) {
      return res.status(404).json({ error: "Shop not found" });
    }

    // Ensure the shop belongs to the authenticated user
    const user = await User.findById(req.user._id);
    if (!user.shops.includes(shop._id)) {
      return res
        .status(403)
        .json({ error: "Forbidden: You do not have access to this shop" });
    }

    // Fetch all containers associated with the canvas
    const canvasJson = JSON.parse(shop.canvas.json);
    const containerIds = canvasJson.objects
      .filter((obj) => obj.id && obj.id.startsWith("container_"))
      .map((obj) => obj.id);

    const containers = await Container.find({
      containerId: { $in: containerIds },
    });

    // Fetch all grids associated with the containers
    const grids = await GridModel.find({ project_id: { $in: containerIds } });

    // Prepare the JSON response
    const shopData = {
      id: shop._id,
      name: shop.name,
      width: shop.width,
      height: shop.height,
      canvas: {
        id: shop.canvas._id,
        json: shop.canvas.json,
        width: shop.canvas.width,
        height: shop.canvas.height,
      },
      containers: containers.map((container) => ({
        id: container._id,
        containerId: container.containerId,
        json: container.json,
        width: container.width,
        height: container.height,
      })),
      grids: grids.map((grid) => ({
        id: grid._id,
        project_id: grid.project_id,
        racks: grid.racks,
        products: grid.products,
        dimensions: grid.dimensions,
      })),
      createdAt: shop.createdAt,
      updatedAt: shop.updatedAt,
    };

    res.json(shopData);
  } catch (error) {
    console.error("Error exporting shop as JSON:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

// Delete Shop API
router.delete("/shop/:id", async (req, res) => {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ error: "Unauthorized" });
  }

  try {
    const shop = await Shop.findById(req.params.id);
    if (!shop) {
      return res.status(404).json({ error: "Shop not found" });
    }

    // Ensure the shop belongs to the authenticated user
    const user = await User.findById(req.user._id);
    if (!user.shops.includes(shop._id)) {
      return res
        .status(403)
        .json({ error: "Forbidden: You do not have access to this shop" });
    }

    // Delete the shop and its associated canvas
    await Canvas.findByIdAndDelete(shop.canvas);
    await Shop.findByIdAndDelete(req.params.id);

    // Remove the shop from the user's shops array
    user.shops = user.shops.filter((id) => id.toString() !== req.params.id);
    await user.save();

    res.json({ message: "Shop deleted successfully" });
  } catch (error) {
    console.error("Error deleting shop:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
